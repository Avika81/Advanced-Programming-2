// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.

using System.ComponentModel;

namespace BasicMVVMQuickstart_Desktop.Model
{
    public class Questionnaire : INotifyPropertyChanged
    {
        #region Notify Changed
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
        #endregion

        private string m_name;
        public string Name {
            get {   return m_name;}
            set
            {
                m_name = value;
                OnPropertyChanged("Name");
            }
        }

        private int m_Age;
        public int Age
        {
            get { return m_Age; }
            set
            {
                m_Age = value;
                OnPropertyChanged("Age");
            }
        }

        private string m_Quest;
        public string Quest
        {
            get { return m_Quest; }
            set
            {
                m_Quest = value;
                OnPropertyChanged("Quest");
            }
        }

        private string m_FavoriteColor;
        public string FavoriteColor
        {
            get { return m_FavoriteColor; }
            set
            {
                m_FavoriteColor = value;
                OnPropertyChanged("FavoriteColor");
            }
        }
    }
}
