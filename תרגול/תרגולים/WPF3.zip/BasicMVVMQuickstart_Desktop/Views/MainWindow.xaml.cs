// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.

using BasicMVVMQuickstart_Desktop.ViewModels;
using System.Windows;

namespace BasicMVVMQuickstart_Desktop.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainWindowViewModel();
        }
    }
}
