﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedFiles
	{
	/// <summary>
	/// Basic connecting data that is used by all the project
	/// </summary>
	public static class ConnectingData
		{
		public static int port = 7676;
		public static String ip = "127.0.0.1";
		}
	}
