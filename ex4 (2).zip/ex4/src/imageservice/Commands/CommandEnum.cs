﻿//no Imports needed as this is just an enum which will be used in other places
namespace ImageService.Commands
{
    public enum CommandEnum : int
    {
        NewFileCommand,
        CloseCommand
    }
}
